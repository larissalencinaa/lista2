var numero1 
var numero2 
var result 

result = (numero1 * numero2); 

numero1 = Number(prompt('digite o numero que voce deseja multiplicar!')) 
numero2 = Number(prompt('digite o numero que voce deseja multiplicar!'))
 
 
 alert ( '0 resultado é:' + result);