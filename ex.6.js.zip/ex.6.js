/* 6) Em uma fábrica de reciclagem de materiais, cada 10kg de plástico rendem R$2,00 cada 30kg de papel rendem R$3,00 e cada 50kg de metal rendem R$5,00. Perguntar ao usuário a quantidade (kg) de cada material que deseja entregar na fábrica e mostrar o total que receberá em reais. 
*/
var kilosdeplastico
var kilosdepapel
var kilosdemetal
var total = kilosdeplastico + kilosdepapel + kilosdemetal;


kilosdemetal = Number(prompt('digite a quantidade de metal em Kg'));
kilosdepapel = Number(prompt('digite a quantidade de papel em Kg'));
kilosdeplastico = Number(prompt('digite a quantidade de plástico em Kg'));

kilosdemetal = (plastico / 10) * 2;
kilosdepapel = (papel / 30) * 3;
kilosdeplastico = (metal / 50) * 5;

alert("Total a receber: R$ " + total);