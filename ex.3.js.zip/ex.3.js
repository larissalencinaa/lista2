/* 3) Programar a conversão de uma temperatura digitada pelo usuário em graus Celsius para Fahrenheit. Mostrar o resultado na tela.  */

var temperaturacelcius
var temperaturafafa

temperaturacelcius = Number(prompt("Temperatura em graus celcius"));
temperaturaemfarenheit = temperaturacelcius * 9/5

alert("A temperatura em F é de:" + temperaturaemfarenheit)



