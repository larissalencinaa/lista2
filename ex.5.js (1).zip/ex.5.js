/* 5) Criar um programa que calcule o IMC, no qual o usuário deve digitar o seu peso e altura, realizar o cálculo (peso / altura * altura) e mostrar o resultado na tela. 
*/

var peso
var altura
var imc

peso =Number(prompt('digite o seu peso'))
altura =Number(prompt('digite o sua altura'))
imc = peso/altura * altura

alert('O seu IMC é de:' + imc)