var convidados = 45;
var choppTotal = 300;

var desperdicio = prompt("Insira a quantidade de chopp desperdiçado (em litros):");
var sobrou = prompt("Insira a quantidade de chopp que sobrou (em litros):");

var choppConsumido = choppTotal - desperdicio - sobrou;
var media = choppConsumido / convidados;

alert("Média de litros bebidos por pessoa: " + media+ " litros");